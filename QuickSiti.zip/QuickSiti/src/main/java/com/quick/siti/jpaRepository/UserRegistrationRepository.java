package com.quick.siti.jpaRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quick.siti.modal.User;

public interface UserRegistrationRepository extends JpaRepository<User, Integer>{

}
