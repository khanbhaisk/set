package com.quick.siti.jpaRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quick.siti.modal.TempUser;

public interface TempUserRepositry extends JpaRepository<TempUser, Integer>{

}
