package com.quick.siti.controlle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.quick.siti.jpaRepository.TempUserRepositry;
import com.quick.siti.jpaRepository.UserRegistrationRepository;
import com.quick.siti.modal.TempUser;
import com.quick.siti.modal.User;

@RestController
@RequestMapping("dum/flok")
public class UserManager {
	
	@Autowired
	UserRegistrationRepository userRegistration;
	
	@Autowired
	TempUserRepositry tempuserRepositry;
	
	@RequestMapping(value = "/user/registration", method = RequestMethod.POST)
	public String userRegister(@RequestBody User user , @PathVariable(value="userPhoneNumber") boolean userPhoneNumber) {
		
		/*{
			"userEmail" :"akramkhan@gmail.com",
			"userPassword" :"123456",
			"userPhoneNumber" :"8013273893",
			"userRefrelCode" : "sv234vfh"
			}*/
		
		userRegistration.save(user);
		return "User Registration has been done";	
	}
	@RequestMapping(value ="/user/tempuser", method=RequestMethod.POST)
	public String TemporUser(@RequestBody TempUser tempuser,@PathVariable(value="userPhoneNumber") boolean userPhoneNumber) {
		//if(userRegister(null, userPhoneNumber));
       if(userPhoneNumber == userPhoneNumber) {
    	   tempuserRepositry.save(tempuser);
    	   return "Temprary user Registration done";
       }
       else {
    	   return "user mobile number already exist";
       }
	}
	
	@RequestMapping("/TestMan")
	public String Test() {
		User obj=new User("Hello","khan","done","ok ji");
		userRegistration.save(obj);
		return "Test is working";
	}
}
