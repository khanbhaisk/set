package com.quick.siti.controlle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quick.siti.jpaRepository.BusDetailsRepository;
import com.quick.siti.jpaRepository.BusRepository;
import com.quick.siti.jpaRepository.ReservationRepository;
import com.quick.siti.jpaRepository.RouteRepository;
import com.quick.siti.modal.Bus;
import com.quick.siti.modal.BusDetails;
import com.quick.siti.modal.Reservation;
import com.quick.siti.modal.Routes;

@RestController
@RequestMapping("rest/admin")
public class ReservationManager {
	@Autowired
	BusRepository busRepo;	
	@Autowired
	BusDetailsRepository busDetailRepo;
	
	@Autowired
	RouteRepository routeRepo;
	@Autowired
	ReservationRepository reservationRepo;
	
	@GetMapping("/reservation")
	public String addBus(){
		
		/*Routes r = new Routes("HOWRAH", "ASANSOL", "HOWRAH-A-B-C-D-E-ASANSOL");
		r.setId(1);
		//routeRepo.save(r);
		Bus b = new Bus("WB12AJ6051", "EXTENDED", "MR. S DAS", "98989898989", "MR. K SING", "9898764534");
		//b.setId(1);
		busRepo.save(b);
		BusDetails bd = new BusDetails("AC", 310, "DOWN", "SUN-TUE-FRI", "8 PM", "1 AM", true, "21,23,", "21,23,24,25,27,30", b,r);
		busDetailRepo.save(bd);*/
		
		BusDetails b =busDetailRepo.findOne(7);
		Reservation r = new Reservation("21,23", "", true, "13-05-2018", b);
		reservationRepo.save(r);
		return "saved";
	}
}
