package com.quick.siti.controlle;
import java.net.InetAddress;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.NtpV3Packet;
import org.apache.commons.net.ntp.TimeInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.quick.siti.jpaRepository.BusDetailsRepository;
import com.quick.siti.jpaRepository.BusRepository;
import com.quick.siti.jpaRepository.RouteRepository;
import com.quick.siti.modal.Bus;
import com.quick.siti.modal.BusDetails;
import com.quick.siti.modal.Routes;
import com.quick.siti.utility.RouteManagerUtility;

@RestController
@RequestMapping("rest/admin")
public class RouteManager {
	
	@Autowired
	BusRepository busRepo;	
	@Autowired
	BusDetailsRepository busDetailRepo;
	
	@Autowired
	RouteRepository routeRepo;
	
		
	
	@GetMapping("/currentTime")
	public String currentTime(){
		String dateStart = "09:29:58";
		String dateStop = "10:31:48";

		//HH converts hour in 24 hours format (0-23), day calculation
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

		Date d1 = null;
		Date d2 = null;

		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(dateStop);

			//in milliseconds
			long diff = d2.getTime() - d1.getTime();

			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);

			System.out.print(diffDays + " days, ");
			System.out.print(diffHours + " hours, ");
			System.out.print(diffMinutes + " minutes, ");
			System.out.print(diffSeconds + " seconds.");
			return diffHours+"";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	@GetMapping("/hello")
	public String welcome(){
		Calendar cal = Calendar.getInstance();
	    Date date=cal.getTime();
	    DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
	    String formattedDate=dateFormat.format(date);
	    System.out.println("Current time of the day using Calendar - 24 hour format: "+ formattedDate);
	    return formattedDate;
	}
	@GetMapping("/defferenceBetweenTwoDate")
	public String defferenceBetweenTwoDate(){	
		Calendar cal = Calendar.getInstance();
	    Date date=cal.getTime();
	    DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
	    String dateStart=dateFormat.format(date);
		String dateStop = "19/05/2018";
		//HH converts hour in 24 hours format (0-23), day calculation
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Date d1 = null;
		Date d2 = null;

		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(dateStop);

			//in milliseconds
			long diff = d2.getTime() - d1.getTime();
			long diffDays = diff / (24 * 60 * 60 * 1000);
			System.out.print(diffDays + " days, ");
			return diffDays+"";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	@RequestMapping(value = "/create/bus", method = RequestMethod.POST)
	public String createBus(@RequestBody Bus bus){
		
	 System.out.println(bus.getBusName());
	 busRepo.save(bus);
		/* SAMPLE structure of Bus
		 * ------------------------------------*
		 * { "busNumber":"busNumber", "busName":"busName", "ownerName":"ownerName",
		 * "ownerMob":"ownerMob", "conductorName":"conductorName",
		 * "conductoMob":"conductoMob" }
		 * 
		 */
		/*//routeRepo.save(r);
		Bus b = new Bus("WB12AJ6051", "EXTENDED", "MR. S DAS", "98989898989", "MR. K SING", "9898764534");
		//b.setId(1);
		busRepo.save(b);
		//BusDetails bd = new BusDetails("AC", 310, "DOWN", "SUN-TUE-FRI", "8 PM", "1 AM", true, "21,23,", "21,23,24,25,27,30", b,r);
		//busDetailRepo.save(bd);
*/		return "bus saved";
	}
	@RequestMapping(value = "/delete/bus/{id}", method = RequestMethod.GET)
	public String deleteBusById(@PathVariable(value = "id") int id){
		busRepo.delete(id);
		return "deleted";
	}
	
	
	@RequestMapping(value = "/create/busdetails/{busId}/{routeId}", method = RequestMethod.POST)
	public String createBusDetails(@RequestBody BusDetails busDetails,
			@PathVariable(value = "busId") int busId,
			@PathVariable(value = "routeId") int routeId){
		/* SAMPLE BUS DETAILS 
		 * 
		 * { "busType":"busType", 
			"fare":200,
			"routeType":"routeType",
			"journeyDate":"journeyDate", 
			"departureTime":"departureTime",
			"arrivalTime":"arrivalTime"
}
		 * 
		 * 
		 */
		
		//Fetching route and bus
		
		Bus fetchedBus = busRepo.findOne(busId);
		Routes fetchedRoute = routeRepo.findOne(routeId);
		busDetails.setRoute(fetchedRoute);
		busDetails.setBus(fetchedBus);
		busDetailRepo.save(busDetails);
		
	return "bus saved";
	}
	@RequestMapping(value = "/delete/busdetails/{id}", method = RequestMethod.GET)
	public String deleteBusDetailsById(@PathVariable(value = "id") int id){
		busDetailRepo.delete(id);
		return "deleted";
	}
	@GetMapping("/getAllBusWithSDDT/{source}/{destination}/{date}")
	public String getAllBusWithSDDT(@PathVariable(value = "source") String source,
			@PathVariable(value = "destination") String destination,
			@PathVariable(value = "date") String date){
		String searchDay=RouteManagerUtility.getDayFromDate(date);
		System.out.println(searchDay);
		List<BusDetails> b =busDetailRepo.findAllBusByBusType(searchDay,source,destination);
		
	return b.toString();
	}
	@GetMapping("/getAllBusWithoutDT/{source}/{destination}")
	public String getAllBusWithoutSDDT(@PathVariable(value = "source") String source,
			@PathVariable(value = "destination") String destination){
		
		String searchDay = RouteManagerUtility.getCurrentDate();
		List<BusDetails> b =busDetailRepo.findAllBusByBusType(searchDay,source,destination);
		
	return b.toString();
	}
	@GetMapping("/getAllTest")
	public String getTest(){
		RouteManagerUtility.getCurrentTime();
		List<Object[]> b =busDetailRepo.findRouteDetails();
		System.out.println();
	return RouteManagerUtility.getDayFromDate("11-05-2018");
	}
	
	@RequestMapping(value = "/create/route", method = RequestMethod.POST)
	public String createRoute(@RequestBody Routes route){
		routeRepo.save(route);
		/*{ 
		 * sample *
		 * ----------
		 * 	"source":"source", 
				"destination":"destination",
				"routeDetails":"routeDetails"
			}
		
		 */
		return "created";
	}
	@RequestMapping(value = "/delete/route/{id}", method = RequestMethod.GET)
	public String deleteRouteById(@PathVariable(value = "id") int id){
		routeRepo.delete(id);
		return "deleted";
	}
}
