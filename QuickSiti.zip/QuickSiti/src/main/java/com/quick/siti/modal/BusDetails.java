package com.quick.siti.modal;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="busdetails")
public class BusDetails {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "BUS_TYPE")
	private String busType;
	
	@Column(name = "FARE")
	private float fare;
	
	@Column(name = "ROUTE_TYPE")
	private String routeType;
	
	@Column(name = "JOURNEY_DATE")
	private String journeyDate;
	
	@Column(name = "DEPARTURE")
	private String departureTime;
	
	@Column(name = "ARRIVAL_TIME")
	private String arrivalTime;
	
	
	
	 public Routes getRoute() {
		return route;
	}

	public void setRoute(Routes route) {
		this.route = route;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "bus_id")
	 private Bus bus;
	
	 @ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "route_id")
	
	private Routes route;
	 
	 
	@Column(name = "RESARVATION_DETAILS")
	@OneToMany(mappedBy = "busdetails", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	 private Set<Reservation> reservationDetails;
	
	public Bus getBus() {
		return bus;
	}

	public void setBus(Bus bus) {
		this.bus = bus;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public float getFare() {
		return fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

	public String getRouteType() {
		return routeType;
	}

	public void setRouteType(String routeType) {
		this.routeType = routeType;
	}

	public String getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(String journeyDate) {
		this.journeyDate = journeyDate;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	

	

	
	public Set<Reservation> getReservationDetails() {
		return reservationDetails;
	}

	public void setReservationDetails(Set<Reservation> reservationDetails) {
		this.reservationDetails = reservationDetails;
	}

	
	public BusDetails(String busType, float fare, String routeType, String journeyDate, String departureTime,
			String arrivalTime, Bus bus, Routes route, Set<Reservation> reservationDetails) {
		super();
		this.busType = busType;
		this.fare = fare;
		this.routeType = routeType;
		this.journeyDate = journeyDate;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.bus = bus;
		this.route = route;
		this.reservationDetails = reservationDetails;
	}

	public BusDetails() {
		
	}

	
	
	
	

}
