package com.quick.siti.jpaRepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.quick.siti.modal.BusDetails;


public interface BusDetailsRepository  extends JpaRepository<BusDetails, Integer>{

	@Query(value = "SELECT * FROM BUSDETAILS WHERE JOURNEY_DATE like %?1% AND ROUTE_ID IN (SELECT ID FROM ROUTE WHERE SOURCE like ?2 AND DESTINATION  like ?3)", nativeQuery = true)
	List<BusDetails> findAllBusByBusType(String searchDay,String source,String destination);
	@Query(value = "SELECT ROUTE_DETAILS FROM Route", nativeQuery = true)
	List<Object[]> findRouteDetails();
}