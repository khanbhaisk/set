package com.quick.siti.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RouteManagerUtility {
	
	public static String getDayFromDate(String date){
		
		
		  SimpleDateFormat format1=new SimpleDateFormat("dd-MM-yyyy");
		  Date dt1;
		try {
			dt1 = format1.parse(date);
			  DateFormat format2=new SimpleDateFormat("E"); 
			  String finalDay=format2.format(dt1);
			 return finalDay.toUpperCase();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	public static String getCurrentDate(){
		SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyy");//dd/MM/yyyy
	    Date now = new Date();
	    String strDate = sdfDate.format(now);
	    System.out.println(strDate);
	    return strDate;
	}
	public static String getCurrentTime(){
		SimpleDateFormat sdfDate = new SimpleDateFormat("hh:mm");
	    Date now = new Date();
	    String currTime = sdfDate.format(now);
	    System.out.println(currTime);
	    return currTime;
	}

}
