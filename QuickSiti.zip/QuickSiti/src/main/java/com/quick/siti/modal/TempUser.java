package com.quick.siti.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;





@Entity
@Table(name="Tempuser")
public class TempUser {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
    private int id;
	
	@Column(name="email")
	private String userEmail;
	
	@Column(name="password")
	private String userPassword;
	
	@Column(name="mobileno")
	private String userPhoneNumber;
	
	@Column(name="referal")
	private String userRefrelCode;

	
	


	public String getUserEmail() {
		return userEmail;
	}


	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public String getUserPhoneNumber() {
		return userPhoneNumber;
	}


	public void setUserPhoneNumber(String userPhoneNumber) {
		this.userPhoneNumber = userPhoneNumber;
	}


	public String getUserRefrelCode() {
		return userRefrelCode;
	}


	public void setUserRefrelCode(String userRefrelCode) {
		this.userRefrelCode = userRefrelCode;
	}


	public TempUser(String userEmail, String userPassword, String userPhoneNumber, String userRefrelCode) {
		super();
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.userPhoneNumber = userPhoneNumber;
		this.userRefrelCode = userRefrelCode;
	}


	public TempUser() {
		super();
	}
	
	

}
